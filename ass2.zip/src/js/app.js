import $ from 'jquery';
import {parseCode} from './code-analyzer';
import {parseCodeJson} from './json-parser';

$(document).ready(function () {
    $('#codeSubmissionButton').click(() => {
        let codeToParse = $('#codePlaceholder').val();
        let args = parseCodeJson($('#assignments').val());
        let parsedCode = parseCode(codeToParse, args);
        // $('#parsedCode').val(JSON.stringify(parsedCode, null, 2));
        $('#parsedCode').val(parsedCode);
    });
});
