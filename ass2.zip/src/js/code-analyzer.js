import * as aeval from 'static-eval';
import * as esprima from 'esprima';
import * as escodegen from 'escodegen'
import {parseCodeJson, makeRecord} from './json-parser';

// const ifStatementHandler = (x) =>{
//
// };
//
// const variableDeclarationHandler = (x) =>{
//
// };
//
// const variableDeclaratorHandler = (x) =>{
//
// };
//
// const sequenceExpressionHandler = (x) =>{
//
// };
// const assignmentExpressionHandler = (x) =>{
//
// };
// const expressionStatementHandler = (x) =>{
//
// };
// const updateExpressionHandler = (x) =>{
//
// };
//
// let Handlers = {
//     'VariableDeclaration': variableDeclarationHandler,
//     'VariableDeclarator': variableDeclaratorHandler,
//     'ExpressionStatement': expressionStatementHandler,
//     'SequenceExpression': sequenceExpressionHandler,
//     'AssignmentExpression': assignmentExpressionHandler,
//     'UpdateExpression' : updateExpressionHandler,
//     'IfStatement': ifStatementHandler,
// };
//
// const findHandler = (x) =>
//     Handlers[x.type](x);

// const getColors = (arr) =>{
//     let ret = [];
//     for (let i = 0; i < arr.length; i++)
//         if(arr[i].Type === 'if statement') {
//             ret.push(aeval(esprima.parse(arr[i].Condition).body[0].expression));
//             // ret.push(arr[i].Line);
//         }
//     return ret;
// };

const reg = (varName) => new RegExp(varName, 'g');

const changeRest = (arr, varName, value) =>{
    if(arr.length === 0)
        return [];
    if(arr[0].type === 'ExpressionStatement' && arr[0].expression.left.name === varName) {
        let head1 = varName + ' = ' + escodegen.generate(arr[0].expression.right).replace(reg(varName), value);
        let head = [esprima.parseScript(head1).body[0]];
        return head.concat(changeRest(arr.slice(1), varName, escodegen.generate(head[0].expression.right)));
    }

    let tmp = escodegen.generate(arr[0]);
    let head = [esprima.parse(tmp.replace(reg(varName), value)).body[0]];
    return head.concat(changeRest(arr.slice(1), varName, value));
};

const parseCode = (codeToParse, args) => {
    let arr = esprima.parse(codeToParse).body;
    for (let i = 0; i < arr.length; i++) {
        if(arr[i].type === 'VariableDeclaration') {
            // return '(' + arr[i].declarations[0].init.value + ')';
            arr = arr.slice(0, i).concat(changeRest(arr.slice(i + 1), arr[i].declarations[0].id.name, '(' + arr[i].declarations[0].init.value + ')'));
        }
    }
    return escodegen.generate({type: 'Program', body:arr});
};

export {parseCode};
